// File: ObjectData.java
// Summary: Contains information about an object in the level.

package base;

import java.util.ArrayList;

public class ObjectData {
	private String cls;
	private ArrayList<Property> properties;
	
	public ObjectData(String cls) {
		setObjectClass(cls);
		properties = new ArrayList<Property>();
	}
	
	public ObjectData() {
		this("");
	}
	
	public String getObjectClass() {
		return cls;
	}
	
	public void setObjectClass(String cls) {
		this.cls = cls;
	}
	
	public boolean hasProperty(String name) {
		for (Property p : properties) {
			if (p.getName().equals(name)) {
				return true;
			}
		}
		
		return false;
	}
	
	public Property getProperty(String name) {
		for (Property p : properties) {
			if (p.getName().equals(name)) {
				return p;
			}
		}
		
		return null;
	}
	
	public Property[] getProperties() {
		Property[] propertiesArray = new Property[properties.size()];
		return properties.toArray(propertiesArray);
	}
	
	public void addProperty(Property p) {
		properties.add(p);
	}
	
	public void removeProperty(Property p) {
		properties.remove(p);
	}
	
	public String toXML(String indent) {
		String xml;
		
		xml = String.format("%s<object class=\"%s\">\n",
			indent, getObjectClass());
		for (Property property : properties) {
			xml += property.toXML(indent + "\t");
		}
		xml += indent + "</object>\n";
		
		return xml;
	}
	
	public String toXML() {
		return toXML("");
	}
}