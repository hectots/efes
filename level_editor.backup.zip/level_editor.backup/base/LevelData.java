// File: LevelData.java
// Summary: Encapsulates the level attributes like the name and conditions.

package base;

import java.util.ArrayList;

public class LevelData {
	private String name;
	private int width;
	private int height;
	private String winCondition;
	private String loseCondition;
	
	public LevelData(
		String name,
		int width,
		int height,
		String winCondition,
		String loseCondition) {
		
		setName(name);
		setWidth(width);
		setHeight(height);
		setWinCondition(winCondition);
		setLoseCondition(loseCondition);
	}
	
	public LevelData(String name, int width, int height) {
		this(name, width, height, "", "");
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getWidth() {
		return width;
	}
	
	public void setWidth(int width) {
		this.width = width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void setHeight(int height) {
		this.height = height;
	}
	
	public String getWinCondition() {
		return winCondition;
	}
	
	public void setWinCondition(String condition) {
		winCondition = condition;
	}
	
	public String getLoseCondition() {
		return loseCondition;
	}
	
	public void setLoseCondition(String condition) {
		loseCondition = condition;
	}
	
	public String toXML() {
		String xml;
		String winAttribute = "";
		String loseAttribute = "";
		
		if (!getWinCondition().equals("")) {
			winAttribute = String.format(" win=\"%s\"", getWinCondition());
		}
		
		if (!getLoseCondition().equals("")) {
			loseAttribute = String.format(" lose=\"%s\"", getLoseCondition());
		}
		
		xml = String.format("<level name=\"%s\" width=\"%d\" height=\"%d\"%s%s>\n",
			getName(), getWidth(), getHeight(), winAttribute, loseAttribute);
		
		return xml;
	}
}