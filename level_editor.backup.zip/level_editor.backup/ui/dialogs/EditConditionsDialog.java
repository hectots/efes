// File: EditConditionDialog.java
// Summary: A dialog to create the wining and losing Condition. 

package ui.dialogs;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class EditConditionsDialog extends JDialog {
	private JButton okButton;
	private JButton cancelButton;
	private JPanel winEditPanel;
	private JPanel loseEditPanel;
	private JLabel instructionsLabel;
	private JLabel winLabel;
	private JLabel loseLabel;
	private String winCondition;
	private String loseCondition;
	
	private int optionChoosed;
	
	public final static int OK_OPTION = 1;
	public final static int CANCEL_OPTION = 2;
	
	private JTextField winTextField;
	private JTextField loseTextField;
	
	public EditConditionsDialog(Frame frame, String winCondition, String loseCondition) {
		super(frame, true);
		
		setSize(385, 180);
		setTitle("Set Win/Lose Condition");
		
		this.winCondition = winCondition;
		this.loseCondition = loseCondition;
		
		initComponents();
		registerListeners();
		
		setOptionChoosed(CANCEL_OPTION);
	}
	
	public String getWinCondition() {
		if (winCondition != null) {
			return winCondition;
		}
		else return "";
	}
	
	public void setWinCondition(String winCondition) {
		this.winCondition = winCondition;
	}
	
	public String getLoseCondition() {
		if (loseCondition != null) {
			return loseCondition;
		}
		else return "";
	}
	
	public void setLoseCondition(String loseCondition) {
		this.loseCondition = loseCondition;
	}
	
	public int getOptionChoosed() {
		return optionChoosed;
	}
	
	private void setOptionChoosed(int optionChoosed) {
		this.optionChoosed = optionChoosed;
	}
	
	private void initComponents() {
		this.setLocationRelativeTo(null);
		
		okButton = new JButton("Ok");
		cancelButton = new JButton("Cancel");
		
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
		
		bottomPanel.add(Box.createHorizontalGlue());
		bottomPanel.add(okButton);
		bottomPanel.add(cancelButton);
		
		this.add(bottomPanel, BorderLayout.SOUTH);
		
		winLabel = new JLabel("Specify the win condition:");
		loseLabel = new JLabel("Specify the lose condition:");
		
		JPanel winEditPanel = new JPanel();
		winEditPanel.setLayout(
			new BoxLayout(winEditPanel, BoxLayout.X_AXIS));
		JPanel loseEditPanel = new JPanel();
		loseEditPanel.setLayout(
			new BoxLayout(loseEditPanel, BoxLayout.X_AXIS));
		
		winTextField = new JTextField(30);
		loseTextField = new JTextField(30);	
		
		winTextField.setText(getWinCondition());
		loseTextField.setText(getLoseCondition());
		
		winEditPanel.add(winTextField);
		loseEditPanel.add(loseTextField);
		
		JPanel newWinEditPanel = new JPanel();
		newWinEditPanel.setLayout(
			new BoxLayout(
				newWinEditPanel,
				BoxLayout.Y_AXIS));
				
		JPanel newLoseEditPanel = new JPanel();
		newLoseEditPanel.setLayout(
			new BoxLayout(
				newLoseEditPanel,
				BoxLayout.Y_AXIS));
		
		newWinEditPanel.add(winEditPanel);
		newLoseEditPanel.add(loseEditPanel);
		
		JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		
		centerPanel.add(winLabel);
		centerPanel.add(newWinEditPanel);
		centerPanel.add(loseLabel);
		centerPanel.add(newLoseEditPanel);
		
		this.add(centerPanel, BorderLayout.CENTER);
		
		centerPanel.validate();
	}
	
	private void registerListeners() {
		
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setOptionChoosed(OK_OPTION);
				setWinCondition(winTextField.getText());
				setLoseCondition(loseTextField.getText());
				setVisible(false);
			}
		});
		
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setOptionChoosed(CANCEL_OPTION);
				setVisible(false);
			}
		});
	}
}