// File: LevelWriter.java
// Summary: Writes a level into a XML formatted file.

package io;

import java.io.*;
import java.util.Formatter;

import base.*;
import ui.panels.CanvasPanel;
import ui.panels.canvas.Graphic;

public class LevelWriter {
	private LevelWriter() {}
	
	public static void write(
		File file, LevelData levelData, CanvasPanel canvasPanel) {
		
		try {
			Formatter writer = new Formatter(file);
		
			writer.format("%s", levelData.toXML());
		
			String[] layers = canvasPanel.getLayers();
			if (layers != null) {
				for (String layer : layers) {
					if (!layer.equals("")) {
						writer.format("\t<layer name=\"%s\">\n", layer);
				
						Graphic[] graphics = canvasPanel.getGraphicsByLayer(layer);
						if (graphics != null) {
							for (Graphic graphic : graphics) {
								ObjectData objectData = graphic.getObjectData();
								writer.format("%s", objectData.toXML("\t\t"));
							}
						}
						writer.format("\t</layer>\n");
					}
				}
			}
		
			writer.format("</level>");
			writer.close();
		} catch (IOException ioException) {
			System.err.printf("Error writting to file %s\n",
				file.getAbsolutePath());
			// System.exit(1);
		} catch (Exception exception) {
			exception.printStackTrace();
			System.exit(1);
		}
	}
}