// File: LevelWriterXML.java
// Summary: Writes a level into a XML formatted file.

package io;

import java.io.*;
import java.util.Formatter;

import base.*;
import ui.panels.CanvasPanel;
import ui.panels.canvas.Graphic;

public class LevelWriterXML {
	private LevelWriterXML() {}
	
	public static void write(
		File file, LevelData levelData, CanvasPanel canvasPanel) {
		
		try {
			Formatter writer = new Formatter(file);
			writer.format("%s",
				LevelWriterXML.writeLevel(levelData, canvasPanel));
			writer.close();
		} catch (IOException ioException) {
			System.err.printf("Error writting to file %s\n",
				file.getAbsolutePath());
		} catch (Exception exception) {
			exception.printStackTrace();
			System.exit(1);
		}
	}
	
	private static String writeLevel(
		LevelData levelData, CanvasPanel canvasPanel) {
		
		String level;
		
		level  = LevelWriterXML.startLevel(levelData);
		level += LevelWriterXML.writeBody(canvasPanel);
		level += LevelWriterXML.endLevel();
		
		return level;
	}
	
	private static String startLevel(LevelData levelData) {
		String levelHeader;
		
		levelHeader = String.format("<level name=\"%s\" width=\"%d\" height=\"%d\">\n",
			levelData.getName(), levelData.getWidth(), levelData.getHeight());
		
		return levelHeader;
	}
	
	private static String writeBody(CanvasPanel canvasPanel) {
		String levelBody = "";
		
		String[] layers = canvasPanel.getLayers();
		if (layers != null) {
			for (String layer : layers) {
				if (!layer.equals("")) {
					levelBody += String.format("\t<layer name=\"%s\">\n", layer);
			
					Graphic[] graphics = canvasPanel.getGraphicsByLayer(layer);
					if (graphics != null) {
						for (Graphic graphic : graphics) {
							ObjectData objectData = graphic.getObjectData();
							levelBody += LevelWriterXML.writeObjectData(objectData);
						}
					}
					
					levelBody += String.format("\t</layer>\n");
				}
			}
		}
		
		return levelBody;
	}
	
	private static String writeObjectData(ObjectData objectData) {
		String object;
		
		object = String.format("\t\t<object class=\"%s\">\n", objectData.getObjectClass());
		for (Property property : objectData.getProperties()) {
			object += LevelWriterXML.writeProperty(property, "\t\t\t");
		}
		object += "\t\t</object>\n";
		
		return object;
	}
	
	private static String writeProperty(Property property, String indent) {
		if (property instanceof CompositeProperty) {
			CompositeProperty compositeProperty = (CompositeProperty)property;
			String properties;
			
			properties = String.format("%s<%s>\n", indent, compositeProperty.getName());
			for (Property innerProperty : compositeProperty.getProperties()) {
				properties += LevelWriterXML.writeProperty(innerProperty, indent + "\t");
			}
			properties += String.format("%s</%s>\n", indent, compositeProperty.getName());
			
			return properties;
		}
		
		return String.format("%s<%s>%s</%s>\n",
			indent, property.getName(), property.getValue(), property.getName());
	}
	
	private static String endLevel() {
		return "</level>";
	}
}